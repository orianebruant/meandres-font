import numpy as np, unicodedata
from fontTools.ttLib import TTFont
from fontTools.pens.basePen import BasePen

class Flat(BasePen):
    def __init__(self,gs):
        super().__init__(gs); self.edges=[]; self.cur=None; self.start=None
    def _moveTo(self,p): self.cur=p; self.start=p
    def _lineTo(self,p): self.edges.append((self.cur,p)); self.cur=p
    def _qCurveToOne(self,p1,p2):
        p0=self.cur
        for t in np.linspace(0,1,9)[1:]:
            q=((1-t)**2*p0[0]+2*(1-t)*t*p1[0]+t*t*p2[0],(1-t)**2*p0[1]+2*(1-t)*t*p1[1]+t*t*p2[1])
            self.edges.append((self.cur,q)); self.cur=q
    def _curveToOne(self,p1,p2,p3):
        p0=self.cur
        for t in np.linspace(0,1,9)[1:]:
            a=(1-t)**3;b=3*(1-t)**2*t;c=3*(1-t)*t*t;d=t**3
            q=(a*p0[0]+b*p1[0]+c*p2[0]+d*p3[0],a*p0[1]+b*p1[1]+c*p2[1]+d*p3[1])
            self.edges.append((self.cur,q)); self.cur=q
    def _closePath(self):
        if self.cur!=self.start: self.edges.append((self.cur,self.start))
        self.cur=self.start
    _endPath=_closePath

def profile(gs,name,ys):
    fp=Flat(gs); gs[name].draw(fp)
    if not fp.edges: return np.full(len(ys),np.nan),np.full(len(ys),np.nan)
    e=np.array([[a[0],a[1],b[0],b[1]] for a,b in fp.edges],float)
    x0,y0,x1,y1=e.T
    L=np.full(len(ys),np.nan); R=np.full(len(ys),np.nan)
    ymin=np.minimum(y0,y1); ymax=np.maximum(y0,y1)
    ok=ymax>ymin
    for i,y in enumerate(ys):
        m=ok&(ymin<=y)&(y<ymax)
        if m.any():
            xs=x0[m]+(y-y0[m])*(x1[m]-x0[m])/(y1[m]-y0[m])
            L[i]=xs.min(); R[i]=xs.max()
    return L,R
