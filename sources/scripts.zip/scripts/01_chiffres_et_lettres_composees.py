import re, copy
from fontTools.ttLib import TTFont
from fontTools.ttLib.removeOverlaps import removeOverlaps
from fontTools.pens.ttGlyphPen import TTGlyphPen
from fontTools.pens.transformPen import TransformPen
from fontTools.pens.recordingPen import RecordingPen
from fontTools.pens.boundsPen import BoundsPen
from fontTools.pens.cu2quPen import Cu2QuPen
from fontTools.svgLib.path import parse_path
from pathops import Path, PathOp, op

SRC="/mnt/user-data/outputs/Meandres/fonts/Meandres-Regular.ttf"
ORIG="/mnt/user-data/uploads/Méandres-Regular.ttf"
f=TTFont(ORIG)
gs=f.getGlyphSet()
cm=f.getBestCmap()
B=108  # ligne de base visuelle des glyphes Calligraphr

# ---------- helpers ----------
def rec(name):
    rp=RecordingPen(); gs[name].draw(rp); return rp.value
def replay(value,pen,T=(1,0,0,1,0,0)):
    rp=RecordingPen(); rp.value=value; rp.replay(TransformPen(pen,T))
def split(value):
    cs=[];cur=[]
    for o,a in value:
        cur.append((o,a))
        if o in("closePath","endPath"): cs.append(cur);cur=[]
    return cs
def bounds(value,T=(1,0,0,1,0,0)):
    bp=BoundsPen(None); replay(value,bp,T); return bp.bounds
def pts(value):
    for o,a in value:
        for p in a:
            if p is not None: yield p
def rect(x0,y0,x1,y1):
    p=Path(); pn=p.getPen()
    pn.moveTo((x0,y0)); pn.lineTo((x1,y0)); pn.lineTo((x1,y1)); pn.lineTo((x0,y1)); pn.closePath(); return p
def to_path(value):
    p=Path(); replay(value,p.getPen()); return p
def intersect(value,r):
    res=op(to_path(value),r,PathOp.INTERSECTION,fix_winding=True)
    rp=RecordingPen(); res.draw(rp); return rp.value
def T_move(dx,dy): return (1,0,0,1,dx,dy)
def T_scale(sx,sy,dx=0,dy=0): return (sx,0,0,sy,dx,dy)
def mul(T,U): # apply T then U
    a,b,c,d,e,g=T; A,Bb,C,D,E,G=U
    return (a*A+b*C, a*Bb+b*D, c*A+d*C, c*Bb+d*D, e*A+g*C+E, e*Bb+g*D+G)

new={}   # name -> (glyph, advance)
def make(parts, adv=None, min_lsb=50, rsb=50):
    """parts: [(value, T)] ; recentre pour que xMin=min_lsb"""
    xs=[];
    for v,T in parts:
        b=bounds(v,T); xs.append(b)
    xmin=min(b[0] for b in xs); xmax=max(b[2] for b in xs)
    shift=min_lsb-xmin
    p=None
    for v,T in parts:
        q=Path(); replay(v,q.getPen(),mul(T,T_move(shift,0)))
        q.simplify(fix_winding=True,keep_starting_points=False)
        p=q if p is None else op(p,q,PathOp.UNION,fix_winding=True)
    pen=TTGlyphPen(None)
    p.draw(pen)
    a=xmax+shift+rsb
    if adv is not None: a=max(a,adv)
    return pen.glyph(), int(round(a))

# ---------- chiffres depuis le SVG ----------
svg=open("/mnt/user-data/uploads/chiffres_meandres.svg").read()
D=re.findall(r' d="([^"]+)"',svg)
S=3.05
digit_paths={0:[8],1:[10,9],2:[7],3:[5],4:[6],5:[4],6:[3],7:[2],8:[1],9:[0]}
row_base={}  # ligne 1 : y~211 ; ligne 2 : y~662
names=["zero","one","two","three","four","five","six","seven","eight","nine"]
def draw_svg(d,pen,T):
    parse_path(d,TransformPen(Cu2QuPen(pen,1.0),T))
for dgt,idxs in digit_paths.items():
    base=662 if dgt in (8,9) else 211
    T0=(S,0,0,-S,0,B+base*S)         # y_font = B + (base - y_svg)*S
    bp=BoundsPen(None)
    for i in idxs: parse_path(D[i],TransformPen(bp,T0))
    xmin,_,xmax,_=bp.bounds
    T=(S,0,0,-S,50-xmin,B+base*S)
    pen=TTGlyphPen(None)
    for i in idxs: draw_svg(D[i],pen,T)
    new[names[dgt]]=(pen.glyph(), int(round(xmax-xmin+100)))

# ---------- accents donneurs ----------
def contours(name): return split(rec(name))
def cbounds(c): return bounds(c)
circ_lc = contours("ocircumflex")[0]          # circonflexe minuscule
circ_uc = contours("Ecircumflex")[0]          # circonflexe majuscule
grave_uc= contours("Egrave")[0]
dots    = contours("edieresis")[:2]           # tréma (2 points)
def cx(c): b=cbounds(c); return (b[0]+b[2])/2
def body(name): # tout sauf contours d'accent (ymin au-dessus du seuil)
    return rec(name)
def flat(cs): return [x for c in cs for x in c]

def apex_x(name):
    v=rec(name); best=max(pts(v),key=lambda p:p[1]); return best[0]

# û ü ï
u=rec("u"); ub=bounds(u); ucx=(ub[0]+ub[2])/2
new["ucircumflex"]=make([(u,T_move(0,0)),(circ_lc,T_move(ucx-cx(circ_lc),0))],adv=366)
dcx=(cbounds(dots[0])[0]+cbounds(dots[1])[2])/2
def dots_over(cxx,ytop,narrow=0):
    # tré ma centré sur cxx, bas des points à ytop
    ymin=min(cbounds(d)[1] for d in dots)
    parts=[]
    for k,d in enumerate(dots):
        sgn=1 if k==0 else -1
        parts.append((d,T_move(cxx-dcx+sgn*narrow,ytop-ymin)))
    return parts
new["udieresis"]=make([(u,T_move(0,0))]+dots_over(ucx,ub[3]+105,18),adv=366)
istem=contours("i")[1]; ib=cbounds(istem)
new["idieresis"]=make([(istem,T_move(0,0))]+dots_over((ib[0]+ib[2])/2,ib[3]+115,22),adv=200)

# majuscules
def over_circ(base,gap=25):
    v=rec(base); b=bounds(v); ax=(b[0]+b[2])/2
    return [(v,T_move(0,0)),(circ_uc,T_move(ax-cx(circ_uc),b[3]+gap-cbounds(circ_uc)[1]))],rec(base)
Ab=bounds(rec("A")); 
parts=[(rec("A"),T_move(0,0)),(circ_uc,T_move(apex_x("A")-cx(circ_uc),Ab[3]+25-cbounds(circ_uc)[1]))]
new["Acircumflex"]=make(parts,adv=519)
parts,_=over_circ("I"); new["Icircumflex"]=make(parts,adv=290)
parts,_=over_circ("U"); new["Ucircumflex"]=make(parts,adv=bounds(rec("U"))[2]+50)
Ub=bounds(rec("U")); Ucx=(Ub[0]+Ub[2])/2
new["Ugrave"]=make([(rec("U"),T_move(0,0)),(grave_uc,T_move(Ucx-45-cx(grave_uc),Ub[3]+34-cbounds(grave_uc)[1]))],adv=Ub[2]+50)
for base,name in (("E","Edieresis"),("I","Idieresis"),("U","Udieresis")):
    v=rec(base); b=bounds(v)
    new[name]=make([(v,T_move(0,0))]+dots_over((b[0]+b[2])/2,b[3]+38,18),adv=b[2]+50)

# Ç : cedille extraite de ç
cc=rec("ccedilla"); ced=intersect(cc,rect(-100,-200,2000,102))
cb=bounds(cc); ccx=(cb[0]+cb[2])/2
Cv=rec("C"); Cb=bounds(Cv); Ccx=(Cb[0]+Cb[2])/2
new["Ccedilla"]=make([(Cv,T_move(0,0)),(ced,T_move(Ccx-ccx+4,0))],adv=481)

# œ Œ
ov=rec("o"); ev=rec("e")
new["oe"]=make([(ov,T_move(0,0)),(ev,T_move(309-36-54,0))],adv=None)
Ov=rec("O"); Ev=rec("E")
new["OE"]=make([(Ov,T_move(0,0)),(Ev,T_move(429-48-51,0))],adv=None)

# « (miroir de »)
gr=rec("guillemotright"); gb=bounds(gr)
new["guillemotleft"]=make([(gr,(-1,0,0,1,gb[0]+gb[2],0))],adv=260)

# ; … 
col=contours("colon"); topdot=col[0]
com=rec("comma")
head=[p for p in pts(com) if p[1]>90]; hx=sum(p[0] for p in head)/len(head)
new["semicolon"]=make([(com,T_move(0,0)),(topdot,T_move(hx-cx(topdot),0))],adv=200)
per=rec("period")
new["ellipsis"]=make([(per,T_move(0,0)),(per,T_move(125,0)),(per,T_move(250,0))])

# trait de H -> tiret
Hv=rec("H"); Hp=to_path(Hv)
mid=op(Hp,rect(215,-500,216,1500),PathOp.INTERSECTION,fix_winding=True)
bar_y=mid.bounds; 
stems=op(Hp,rect(-100,150,1000,160),PathOp.INTERSECTION,fix_winding=True)
sb=sorted([c.bounds for c in stems.contours],key=lambda b:b[0])
xl,xr=sb[0][2],sb[-1][0]
bar=intersect(Hv,rect(xl+16,bar_y[1]-4,xr-16,bar_y[3]+4))
bb=bounds(bar); print("bar",bb,"stems",sb)
bw=bb[2]-bb[0]; bcy=(bb[1]+bb[3])/2
def bar_T(cy=300,sx=1.0,x0=0,rot=False):
    # recentre le trait : xmin=x0, centre y = cy
    if not rot:
        return (sx,0,0,1,x0-bb[0]*sx,cy-bcy)
new["hyphen"]=make([(bar,bar_T(300))])
new["endash"]=make([(bar,bar_T(300,1.7))])
new["emdash"]=make([(bar,bar_T(300,2.9))])
new["equal"]=make([(bar,bar_T(250)),(bar,bar_T(380))])
# + : tiret + tiret pivoté de 90°
bcx=(bb[0]+bb[2])/2
vert=(0,1,-1,0,0,0)  # rotation 90°
vb=bounds(bar,vert)
plus_h=bar_T(300)
hc_x=50+bw/2
new["plus"]=make([(bar,plus_h),(bar,mul(vert,T_move(hc_x-(vb[0]+vb[2])/2,300-(vb[1]+vb[3])/2)))])

# parenthèses depuis C
Cb=bounds(Cv)
sx,sy=0.52,1.38
T_par=(sx,0,0,sy,0,0)
pb=bounds(Cv,T_par)
dy=-85-pb[1]
new["parenleft"]=make([(Cv,mul(T_par,T_move(0,dy)))],adv=None)
pbl=bounds(Cv,mul(T_par,T_move(0,dy)))
new["parenright"]=make([(Cv,mul(mul(T_par,T_move(0,dy)),(-1,0,0,1,pbl[0]+pbl[2],0)))],adv=None)

# apostrophes et guillemets depuis la virgule
cb2=bounds(com); k=0.85
def comma_T(rot=False,dx=0,ytop=761):
    if not rot:
        return (k,0,0,k,dx-cb2[0]*k, ytop-cb2[3]*k)
    return (-k,0,0,-k,dx+cb2[2]*k, ytop-(cb2[1]*-k)-0+0)  # rotation 180° (recalé ci-dessous)
def place(rot,dx,ytop=761):
    T=(-k,0,0,-k,0,0) if rot else (k,0,0,k,0,0)
    b=bounds(com,T)
    return mul(T,T_move(dx-b[0], ytop-b[3]))
new["quoteright"]=make([(com,place(False,0))],adv=None)
new["quoteleft"]=make([(com,place(True,0))],adv=None)
new["quotedblright"]=make([(com,place(False,0)),(com,place(False,120))],adv=None)
new["quotedblleft"]=make([(com,place(True,0)),(com,place(True,120))],adv=None)

# € : C + deux traits
bar2=bar; 
eC=bounds(Cv)
x_left=eC[0]-30
def eb(cy): return (1.0,0,0,1,x_left-bb[0],cy-bcy)
new["Euro"]=make([(Cv,T_move(0,0)),(bar,eb(372)),(bar,eb(462))],adv=None)

# ---------- insertion ----------
unic={"zero":0x30,"one":0x31,"two":0x32,"three":0x33,"four":0x34,"five":0x35,"six":0x36,"seven":0x37,"eight":0x38,"nine":0x39,
 "semicolon":0x3B,"parenleft":0x28,"parenright":0x29,"hyphen":0x2D,"plus":0x2B,"equal":0x3D,
 "guillemotleft":0xAB,"ellipsis":0x2026,"endash":0x2013,"emdash":0x2014,"quoteright":0x2019,"quoteleft":0x2018,
 "quotedblleft":0x201C,"quotedblright":0x201D,"Euro":0x20AC,"oe":0x153,"OE":0x152,
 "idieresis":0xEF,"udieresis":0xFC,"ucircumflex":0xFB,"Acircumflex":0xC2,"Icircumflex":0xCE,"Ucircumflex":0xDB,
 "Ugrave":0xD9,"Ccedilla":0xC7,"Edieresis":0xCB,"Idieresis":0xCF,"Udieresis":0xDC}
assert set(unic)==set(new),(set(unic)^set(new))
glyf=f["glyf"]; hmtx=f["hmtx"]
order=f.getGlyphOrder()[:]
for n,(g,a) in new.items():
    order.append(n)
    glyf.glyphs[n]=g
    hmtx.metrics[n]=(a,50)
f.setGlyphOrder(order); glyf.glyphOrder=order
for n in new:
    glyf[n].recalcBounds(glyf)
removeOverlaps(f,glyphNames=set(new),removeHinting=False)
for n,(g,a) in new.items():
    gg=glyf[n]; gg.recalcBounds(glyf)
    hmtx.metrics[n]=(a,gg.xMin if gg.numberOfContours else 0)
# cmap
for t in f["cmap"].tables:
    if t.isUnicode():
        for n,c in unic.items(): t.cmap[c]=n
    elif t.platformID==1:
        for n,c in unic.items():
            if c<128: t.cmap[c]=n
# version et métadonnées
f["head"].fontRevision=1.003
for r in f["name"].names:
    if r.nameID==5: r.string="Version 1.003"
    if r.nameID==3: pass
copyright="Copyright 2026 The Méandres Project Authors (oriane.bruant@gmail.com)"
lic="This Font Software is licensed under the SIL Open Font License, Version 1.1. This license is available with a FAQ at: https://openfontlicense.org"
note="Created with Calligraphr.com. Released under the SIL Open Font License 1.1."
for nid,val in {0:copyright,9:"Oriane Bruant",13:lic,14:"https://openfontlicense.org",10:note}.items():
    f["name"].setName(val,nid,3,1,0x409); f["name"].setName(val,nid,1,0,0)
try: f["OS/2"].recalcUnicodeRanges(f)
except Exception as e: print("ur",e)
f.save("/tmp/build/Meandres-Regular.ttf")
g=TTFont("/tmp/build/Meandres-Regular.ttf"); g.flavor="woff2"; g.save("/tmp/build/Meandres-Regular.woff2")
print("ok",len(f.getGlyphOrder()),"glyphes")
