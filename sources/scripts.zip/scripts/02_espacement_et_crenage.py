import sys, io, unicodedata
sys.path.insert(0,"/tmp/sp")
from lib import *
from fontTools.otlLib.builder import buildPairPosClassesSubtable, buildValue

SRC="/mnt/user-data/outputs/Meandres/fonts/Meandres-Regular.ttf"
OUT=sys.argv[1] if len(sys.argv)>1 else "/tmp/sp/new.ttf"
P=dict(depth=54, lo=18, hi=100, tight=1.0, GMAX=200, F=0.7, MINGAP=26, space=210, zl=360, zu=570, ztop=630, minkern=10)
f=TTFont(SRC); gs=f.getGlyphSet(); cm=f.getBestCmap(); inv={}
for c,n in cm.items(): inv.setdefault(n,c)
B=108
glyf=f["glyf"]; hmtx=f["hmtx"]; order=f.getGlyphOrder()
def cat_of(n):
    cp=inv.get(n)
    if cp is None and "." in n and n[0]!=".": cp=inv.get(n.split(".")[0])
    if cp is None: return None,None
    return unicodedata.category(chr(cp)),cp
def base_char(n):
    cat,cp=cat_of(n)
    if cp is None: return None
    if n in ("oe","OE") or n.startswith(("oe.","OE.")): return None   # lettres propres
    d=unicodedata.normalize("NFD",chr(cp))
    return d[0] if len(d)>1 and "." not in n else None
ysAll=np.arange(B+2,B+P["ztop"]+200,3)
def prof(n): return profile(gs,n,ysAll)
def zone_mask(cat): return ysAll<=B+(P["zl"] if cat=="Ll" else P["zu"])
def sides(n,cat):
    L,R=prof(n); ink=~np.isnan(L)
    if ink.sum()<5: return None
    z=zone_mask(cat); minA=np.nanmin(L); maxA=np.nanmax(R); d=P["depth"]
    dL=np.where(ink,np.minimum(L-minA,d),d)[z]; dR=np.where(ink,np.minimum(maxA-R,d),d)[z]
    zi=ink&z
    return minA,maxA,dL.mean(),dR.mean(),(np.nanmin(L[zi]) if zi.any() else minA)
# calibration
def cal(spec,cat):
    v=[]
    for ch,side in spec:
        n=cm[ord(ch)]; s=sides(n,cat)
        v.append(s[0]-0+s[2] if side=="L" else (hmtx[n][0]-s[1])+s[3])
    return float(np.mean(v))*P["tight"]
S_l=cal([("n","L"),("n","R"),("m","L"),("m","R"),("u","L"),("u","R"),("b","L"),("d","R")],"Ll")
S_u=cal([(c,"L") for c in "HNMEFLDBPRK"]+[(c,"R") for c in "HNMU"],"Lu")
print("S lower %.1f upper %.1f"%(S_l,S_u))
newpos={}   # base -> (dx, adv, minL_zone)
changes={}
variants=[]
for n in order:
    if n in (".notdef",".null") or glyf[n].numberOfContours==0: continue
    cat,cp=cat_of(n)
    if cat not in ("Ll","Lu","Nd"): continue
    if base_char(n): variants.append(n); continue
    zc="Ll" if cat=="Ll" else "Lu"
    s=sides(n,zc)
    if not s: continue
    minA,maxA,aL,aR,minZ=s; S=S_l if cat=="Ll" else S_u
    lsb=min(max(S-aL,P["lo"]),P["hi"]); rsb=min(max(S-aR,P["lo"]),P["hi"])
    dx=lsb-minA; adv=lsb+(maxA-minA)+rsb
    changes[n]=(dx,adv); newpos[n]=(dx,adv,minZ)
for n in variants:
    cat,cp=cat_of(n); b=cm.get(ord(base_char(n)))
    if b not in newpos: continue
    zc="Ll" if cat=="Ll" else "Lu"
    s=sides(n,zc); 
    if not s: continue
    dxb,advb,minZb=newpos[b]
    changes[n]=(minZb+dxb-s[4], advb)
for n,(dx,adv) in changes.items():
    g=glyf[n]; g.coordinates.translate((dx,0)); g.recalcBounds(glyf)
    hmtx.metrics[n]=(int(round(adv)),int(round(g.xMin)))
hmtx.metrics[cm[32]]=(P["space"],0)
buf=io.BytesIO(); f.save(buf); buf.seek(0)
f=TTFont(buf); gs=f.getGlyphSet(); glyf=f["glyf"]; hmtx=f["hmtx"]
# ---- crénage
bases=[cm[ord(c)] for c in "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"]+["oe","OE"]
cls={}
for n in f.getGlyphOrder():
    cat,cp=cat_of(n)
    if cat not in ("Ll","Lu","Nd"): continue
    if n in bases: cls.setdefault(n,[]).append(n); continue
    bc=base_char(n)
    if bc: 
        b=cm.get(ord(bc))
        if b in bases: cls.setdefault(b,[]).append(n)
    elif "." in n and n.split(".")[0] in bases: cls.setdefault(n.split(".")[0],[]).append(n)
ysK=np.arange(B+2,B+P["ztop"]+1,3)
PR={b:profile(gs,b,ysK) for b in bases}
adv={b:hmtx[b][0] for b in bases}
isLow=lambda n: cat_of(n)[0]=="Ll"
def measure(a,b):
    La,Ra=PR[a]; Lb,Rb=PR[b]
    inkA=~np.isnan(La); inkB=~np.isnan(Lb)
    gap=(adv[a]+Lb)-Ra
    both=inkA&inkB
    if not both.any(): return None,np.inf
    return np.minimum(gap[both],P["GMAX"]).mean(),gap[both].min()
refL=np.mean([measure(cm[ord(a)],cm[ord(b)])[0] for a,b in ["nn","mm","hn","um","nu","nh"]])
refU=np.mean([measure(cm[ord(a)],cm[ord(b)])[0] for a,b in ["HH","HN","NH","NN","MH","HM","UH"]])
print("G_ref low %.1f up %.1f"%(refL,refU))
pairs={}; kv={}
for a in bases:
    for b in bases:
        G,gmin=measure(a,b)
        if G is None: continue
        ref=refL if (isLow(a) and isLow(b)) else refU
        k=max((ref-G)*P["F"],P["MINGAP"]-gmin)
        k=int(round(k/5.0)*5)
        if abs(k)<P["minkern"]: continue
        lim=(-35,25) if (cat_of(a)[0]=='Nd' or cat_of(b)[0]=='Nd') else (-140,50)
        k=max(lim[0],min(lim[1],k))
        if abs(k)<P['minkern']: continue
        kv[(a,b)]=k
        pairs[(tuple(cls[a]),tuple(cls[b]))]=(buildValue({"XAdvance":k}),None)
print("paires crénées:",len(kv))
def show(ps): print(", ".join(f"{x}:{kv.get((cm[ord(x[0])],cm[ord(x[1])]),0)}" for x in ps))
show(["AV","AT","AY","LT","TA","To","Ty","VA","Wa","Yo","Pa","Fa","rv","ov","vo","wa","yo","fo","LY","Ta","ll","nn","oo","ar","xe","fl","T0","11"])
st=buildPairPosClassesSubtable(pairs,f.getReverseGlyphMap())
lk=f["GPOS"].table.LookupList.Lookup[0]; lk.SubTable=[st]; lk.SubTableCount=1
f["head"].fontRevision=1.004
for r in f["name"].names:
    if r.nameID==5: r.string="Version 1.004"
f.save(OUT); print("écrit",OUT)
