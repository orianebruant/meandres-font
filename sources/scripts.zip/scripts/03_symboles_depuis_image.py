import sys, io
import numpy as np, potrace
from PIL import Image
from fontTools.ttLib import TTFont
from fontTools.ttLib.removeOverlaps import removeOverlaps
from fontTools.pens.ttGlyphPen import TTGlyphPen
from fontTools.pens.cu2quPen import Cu2QuPen
from fontTools.pens.transformPen import TransformPen
from pathops import Path

SRC="/mnt/user-data/outputs/Meandres/fonts/Meandres-Regular.ttf"
OUT=sys.argv[1] if len(sys.argv)>1 else "/tmp/sym/new.ttf"
K=8.2; B=108; BASE_IMG=1122; UP=4
im=Image.open("/mnt/user-data/uploads/1795434769677_image.png").convert("RGBA")
bg=Image.new("RGBA",im.size,(255,255,255,255)); bg.alpha_composite(im)
gray=bg.convert("L")

def trace(bbox,mar=5):
    x0,x1,y0,y1=bbox; x0-=mar;y0-=mar;x1+=mar;y1+=mar
    crop=gray.crop((x0,y0,x1+1,y1+1))
    big=crop.resize((crop.width*UP,crop.height*UP),Image.LANCZOS)
    arr=np.array(big)>=128
    bm=potrace.Bitmap(arr)
    pl=bm.trace(turdsize=6,alphamax=1.0,opticurve=True,opttolerance=0.3)
    p=Path(); pen=p.getPen()
    def pt(q): return (q.x/UP+x0, q.y/UP+y0)
    def T(q):
        X,Y=pt(q); return (X*K, B+(BASE_IMG-Y)*K)
    for curve in pl:
        pen.moveTo(T(curve.start_point))
        for s in curve.segments:
            if s.is_corner:
                pen.lineTo(T(s.c)); pen.lineTo(T(s.end_point))
            else:
                pen.curveTo(T(s.c1),T(s.c2),T(s.end_point))
        pen.closePath()
    p.simplify(fix_winding=True,keep_starting_points=False)
    return p

def glyph_from(path,lsb,rsb,dy=0):
    bx=path.bounds
    tp=TTGlyphPen(None)
    path.draw(TransformPen(Cu2QuPen(tp,0.8),(1,0,0,1,lsb-bx[0],dy)))
    g=tp.glyph()
    return g,int(round(bx[2]-bx[0]+lsb+rsb))

# bbox: x0,x1,y0,y1 (pixels de l'image)
SYM={
 "parenleft":  ((896,912,1049,1131),40,40,0),
 "parenright": ((971,989,1046,1130),40,40,0),
 "Euro":       ((1007,1066,1055,1111),45,45,0),
 "dollar":     ((1094,1135,1035,1120),45,45,0),
 "numbersign": ((736,778,1082,1130),45,45,0),
 "asterisk":   ((831,857,1055,1078),40,40,0),
 "underscore": ((1217,1269,1108,1113),0,0,-150),   # abaissé sous la ligne de base
 "quotedblleft":  ((559,581,1055,1075),45,45,0),
 "quotedblright": ((661,681,1051,1073),45,45,0),
}
UNI={"dollar":0x24,"numbersign":0x23,"asterisk":0x2A,"underscore":0x5F}
f=TTFont(SRC); glyf=f["glyf"]; hmtx=f["hmtx"]; order=f.getGlyphOrder()[:]
new=[]
for name,(bb,lsb,rsb,dy) in SYM.items():
    path=trace(bb)
    g,adv=glyph_from(path,lsb,rsb,dy)
    if name not in glyf.keys():
        order.append(name); new.append(name)
    glyf.glyphs[name]=g; hmtx.metrics[name]=(adv,lsb)
f.setGlyphOrder(order); glyf.glyphOrder=order
for n in SYM: glyf[n].recalcBounds(glyf)
removeOverlaps(f,glyphNames=set(SYM),removeHinting=False)
for n in SYM:
    g=glyf[n]; g.recalcBounds(glyf); a=hmtx.metrics[n][0]; hmtx.metrics[n]=(a,g.xMin)
for t in f["cmap"].tables:
    if t.isUnicode():
        for n,c in UNI.items(): t.cmap[c]=n
    elif t.platformID==1:
        for n,c in UNI.items(): t.cmap[c]=n
f["head"].fontRevision=1.005
for r in f["name"].names:
    if r.nameID==5: r.string="Version 1.005"
try: f["OS/2"].recalcUnicodeRanges(f)
except Exception as e: print(e)
f.save(OUT); print("ok",OUT,"nouveaux:",new,"total",len(order))
for n in SYM:
    g=f["glyf"][n]; print(n,"adv",f["hmtx"][n][0],"bbox",g.xMin,g.yMin,g.xMax,g.yMax,"contours",g.numberOfContours)
